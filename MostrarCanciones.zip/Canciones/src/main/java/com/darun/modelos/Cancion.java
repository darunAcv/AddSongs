package com.darun.modelos;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="canciones")
public class Cancion {
	
	//ATRIBUTOS
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)//AutoIncremento
	private Long id;
	private String title;
	private String artistName;
	private String album;
	private String genre;
	private String language;
	
	

	@Temporal(TemporalType.TIMESTAMP)
	@Column(updatable=false)
	private Date createdAt;
	
	@Temporal(TemporalType.TIMESTAMP)
	
	private Date updatedAt;
	
	//CONSTRUCTORES
	public Cancion() {
		
	}
	
	public Cancion(Long id, String title, String artistName, String album, String genre, String language,
			Date createdAt, Date updatedAt) {
		this.id = id;
		this.title = title;
		this.artistName = artistName;
		this.album = album;
		this.genre = genre;
		this.language = language;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}

	
	//GETTERS AND SETTERS
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getArtistName() {
		return artistName;
	}

	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	//FECHAS
	
	@PrePersist
    protected void onCreate() {
        this.createdAt = new Date();
    }
	
	@PreUpdate
    protected void onUpdate() {
        this.updatedAt = new Date();
    }

	
}
