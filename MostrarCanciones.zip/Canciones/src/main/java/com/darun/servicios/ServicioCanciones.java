package com.darun.servicios;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.darun.modelos.Cancion;
import com.darun.repositorios.RepositorioCanciones;

@Service
public class ServicioCanciones {
	
	@Autowired
	private RepositorioCanciones repo;
	
	public List<Cancion> obtenerTodasLasCanciones(){
		return repo.findAll();
	}
	
	public Cancion obtenerCancionPorId(Long id) {
		//que hacer para tener la opcion de que no este buscando una id válida
		Optional <Cancion> optional= repo.findById(id);
		return optional.orElse(null);
	}
	
	/*public Cancion agregarCancion(Cancion cancion) {
		
	}*/

}
